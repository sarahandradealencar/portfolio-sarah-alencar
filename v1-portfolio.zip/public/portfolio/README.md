# Entre Linhas — Portfólio de Sarah Alencar

Portfólio pessoal responsivo desenvolvido para a AC02 de Planejamento e Implementação de um Portfólio Pessoal. O projeto apresenta formação, competências, experiências profissionais e voluntárias, uma entrega web concluída, frentes de estudo, hobbies, viagens e formas reais de contato.

O MVP está concluído e publicado. A entrega inclui requisitos rastreáveis, conteúdo profissional, acessibilidade, responsividade e otimizações de carregamento sem frameworks de interface.

## Identificação da aluna

- **Nome:** Sarah Rafaely Andrade Alencar
- **Prontuário:** `GU3078698`
- **Instituição:** Instituto Federal de São Paulo — IFSP
- **Curso:** Análise e Desenvolvimento de Sistemas
- **Semestre:** 2º semestre
- **Previsão de conclusão:** 1º semestre de 2028

## Tecnologias

- HTML5
- CSS3
- JavaScript

O projeto entregue não utiliza frameworks ou bibliotecas de interface.

## Como executar

1. Extraia o arquivo ZIP.
2. Abra a pasta `portfolio`.
3. Clique duas vezes no arquivo `index.html`.
4. O portfólio será aberto no navegador padrão.

Não é necessário instalar dependências ou executar servidor.

## Funcionalidades

- navegação por seções;
- menu para dispositivos móveis;
- animações suaves durante a rolagem;
- filtro de projetos;
- tema claro e escuro com preferência salva localmente;
- botão para copiar o e-mail;
- galeria de viagens com detalhes;
- formulário validado que abre o aplicativo de e-mail;
- links reais de e-mail e Instagram;
- layout responsivo e acessível por teclado;
- carregamento otimizado com imagem WebP, script adiado e renderização progressiva das seções.

## Estrutura

```text
portfolio/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── script.js
├── assets/
│   ├── sarah-profile.jpeg
│   └── sarah-profile.webp
├── docs/
│   ├── documentacao.md
│   └── documentacao.pdf
└── README.md
```

## Documentação

A documentação completa está disponível em:

- `docs/documentacao.md`
- `docs/documentacao.pdf`

## Publicação

Versão publicada: <https://portfolio-sarah-alencar.sarahandradealencar.chatgpt.site>
