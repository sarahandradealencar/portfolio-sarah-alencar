const root = document.documentElement;
const body = document.body;
const menuButton = document.querySelector('.menu-toggle');
const mainNav = document.querySelector('.main-nav');
const themeButton = document.querySelector('.theme-toggle');
const themeIcon = document.querySelector('.theme-icon');

function setMenu(open) {
  mainNav.classList.toggle('is-open', open);
  body.classList.toggle('menu-open', open);
  menuButton.setAttribute('aria-expanded', String(open));
  menuButton.querySelector('.sr-only').textContent = open ? 'Fechar menu' : 'Abrir menu';
}

menuButton.addEventListener('click', () => setMenu(!mainNav.classList.contains('is-open')));
mainNav.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => setMenu(false)));
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') setMenu(false);
});

function applyTheme(theme) {
  root.dataset.theme = theme;
  themeIcon.textContent = theme === 'dark' ? '☼' : '◐';
  themeButton.setAttribute('aria-label', theme === 'dark' ? 'Ativar tema claro' : 'Ativar tema escuro');
}

const storedTheme = localStorage.getItem('portfolio-theme');
const initialTheme = root.dataset.theme || storedTheme || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
applyTheme(initialTheme);

themeButton.addEventListener('click', () => {
  const nextTheme = root.dataset.theme === 'dark' ? 'light' : 'dark';
  applyTheme(nextTheme);
  localStorage.setItem('portfolio-theme', nextTheme);
});

const revealItems = document.querySelectorAll('.reveal');
if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver((entries, currentObserver) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        currentObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  revealItems.forEach((item) => observer.observe(item));
} else {
  revealItems.forEach((item) => item.classList.add('is-visible'));
}

const filterButtons = document.querySelectorAll('.filter-button');
const projectCards = document.querySelectorAll('.project-card');
filterButtons.forEach((button) => {
  button.addEventListener('click', () => {
    const filter = button.dataset.filter;
    filterButtons.forEach((item) => {
      const active = item === button;
      item.classList.toggle('is-active', active);
      item.setAttribute('aria-pressed', String(active));
    });
    projectCards.forEach((card) => {
      const categories = card.dataset.category.split(' ');
      card.classList.toggle('is-hidden', filter !== 'all' && !categories.includes(filter));
    });
  });
});

const copyButton = document.querySelector('.copy-button');
const copyStatus = document.querySelector('.copy-status');
copyButton.addEventListener('click', async () => {
  const email = copyButton.dataset.email;
  try {
    await navigator.clipboard.writeText(email);
  } catch {
    const temporaryInput = document.createElement('input');
    temporaryInput.value = email;
    temporaryInput.setAttribute('readonly', '');
    temporaryInput.style.position = 'fixed';
    temporaryInput.style.opacity = '0';
    document.body.appendChild(temporaryInput);
    temporaryInput.select();
    document.execCommand('copy');
    temporaryInput.remove();
  }
  copyStatus.textContent = 'E-mail copiado com sucesso.';
  window.setTimeout(() => { copyStatus.textContent = ''; }, 3500);
});

const travelDialog = document.querySelector('#travel-dialog');
const dialogTitle = document.querySelector('#dialog-title');
const dialogDetail = document.querySelector('#dialog-detail');
const dialogClose = document.querySelector('.dialog-close');

document.querySelectorAll('.travel-card').forEach((card) => {
  card.addEventListener('click', () => {
    dialogTitle.textContent = card.dataset.place;
    dialogDetail.textContent = card.dataset.detail;
    travelDialog.showModal();
  });
});

dialogClose.addEventListener('click', () => travelDialog.close());
travelDialog.addEventListener('click', (event) => {
  if (event.target === travelDialog) travelDialog.close();
});

const contactForm = document.querySelector('#contact-form');
contactForm.addEventListener('submit', (event) => {
  event.preventDefault();
  if (!contactForm.reportValidity()) return;

  const formData = new FormData(contactForm);
  const name = formData.get('nome').trim();
  const email = formData.get('email').trim();
  const message = formData.get('mensagem').trim();
  const subject = encodeURIComponent(`Contato pelo portfólio — ${name}`);
  const bodyText = `Olá, Sarah!\n\n${message}\n\nNome: ${name}\nE-mail: ${email}`;
  window.location.href = `mailto:sarahandradealencar@gmail.com?subject=${subject}&body=${encodeURIComponent(bodyText)}`;
});
