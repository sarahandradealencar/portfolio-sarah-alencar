# Portfólio de Sarah Alencar

## Produto e público

Portfólio pessoal de Sarah Rafaely Andrade Alencar, estudante de Análise e Desenvolvimento de Sistemas no IFSP. O público inclui docentes, colegas, recrutadores e pessoas interessadas em seu trabalho.

## Objetivo

Apresentar formação, experiências, competências, projetos e formas de contato com clareza, sem inventar entregas ou qualificações. A navegação deve funcionar em computadores e celulares, com teclado e tecnologias assistivas.

## Conteúdo e limites

Preservar os fatos e as funções existentes: seções Sobre, Repertório, Experiências, Projetos, Viagens e Contato; filtro de projetos, tema claro/escuro, galeria de viagens, cópia de e-mail e formulário que abre o aplicativo de e-mail. Nesta v2, acrescentar o catálogo de comandos Impeccable e o registro verificável das intervenções na interface.

## Critério de sucesso

Uma pessoa consegue entender o perfil e encontrar projetos e contato sem esforço. A versão anterior permanece recuperável como `v1`, enquanto a v2 documenta decisões, evidências e limitações.
