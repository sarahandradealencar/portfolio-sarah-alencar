# AC02 — Planejamento e Implementação de um Portfólio Pessoal

**Projeto:** Entre Linhas — Portfólio de Sarah Alencar  
**Aluna:** Sarah Rafaely Andrade Alencar  
**Prontuário:** GU3078698  
**Instituição:** Instituto Federal de São Paulo — IFSP  
**Curso:** Análise e Desenvolvimento de Sistemas  
**Semestre:** 2º semestre  
**Previsão de conclusão:** 1º semestre de 2028  

> **Como ler este arquivo:** este PDF corresponde à documentação exigida pela atividade. O site publicado e os arquivos HTML, CSS e JavaScript presentes no ZIP correspondem à implementação funcional do portfólio.

---

## 1. Definição do projeto

### 1.1 Nome do projeto

**Entre Linhas — Portfólio de Sarah Alencar**.

O nome relaciona a estética de journal e scrapbook com a ideia de que uma trajetória profissional é construída por diferentes registros: formação, experiências, projetos, competências, interesses e escolhas.

### 1.2 Problema ou necessidade atendida

As informações acadêmicas, profissionais e pessoais da autora estavam dispersas e não existia uma apresentação digital única que organizasse sua trajetória de maneira clara, profissional e acessível. O projeto atende à necessidade de reunir essas informações em um portfólio responsivo que possa ser apresentado ao público geral, a professores e a possíveis contatos profissionais.

### 1.3 Objetivo principal

Planejar, documentar e implementar um portfólio pessoal funcional que apresente a identidade de Sarah, sua formação em Análise e Desenvolvimento de Sistemas, conhecimentos, competências, experiências profissionais e voluntárias, uma entrega web concluída, frentes de estudo, hobbies, viagens e formas reais de contato.

### 1.4 Público-alvo

O portfólio é direcionado ao público geral, com atenção especial a:

- professores e avaliadores acadêmicos;
- recrutadores e empresas;
- pessoas interessadas em conhecer a trajetória da autora;
- possíveis parceiros de projetos e contatos profissionais.

### 1.5 Proposta visual

A proposta visual combina **journal editorial**, **scrapbook sofisticado** e apresentação profissional. A inspiração foi uma composição de portfólio com tipografia expressiva, recortes, fotos, anotações e organização em páginas. Para evitar aparência excessivamente juvenil, foram adotados:

- paleta de creme, rosa queimado, vinho e dourado envelhecido;
- títulos editoriais com tipografia serifada;
- detalhes manuscritos usados apenas como acentos;
- retrato profissional em moldura inspirada em polaroide;
- recortes, fitas e cartões com movimentos discretos;
- espaços amplos, contraste adequado e hierarquia consistente;
- animações suaves e opcionais, respeitando preferência por movimento reduzido.

### 1.6 Conteúdo apresentado

O portfólio possui as seguintes seções:

1. apresentação pessoal;
2. formação acadêmica e complementar;
3. tecnologias, ferramentas e competências pessoais;
4. idiomas;
5. experiências profissionais, internacionais, voluntárias e empreendedoras;
6. projeto web concluído e frentes de estudo em desenvolvimento;
7. hobbies e lazer;
8. viagens marcantes;
9. contato por e-mail e Instagram.

### 1.7 Principais funcionalidades

- navegação por âncoras entre as seções;
- menu adaptado para dispositivos móveis;
- animações de entrada durante a rolagem;
- filtro dos projetos por categoria;
- alternância entre tema claro e escuro;
- gravação local da preferência de tema;
- botão para copiar o endereço de e-mail;
- galeria de viagens com janela de detalhes;
- formulário validado que abre o aplicativo de e-mail;
- links reais de e-mail e Instagram;
- layout responsivo e navegação por teclado.

### 1.8 Tecnologias utilizadas

- **HTML5:** estrutura semântica do conteúdo;
- **CSS3:** identidade visual, responsividade, temas e estados interativos;
- **JavaScript:** menu, animações, filtros, tema, cópia de e-mail, galeria e formulário;
- **Git:** organização e versionamento do projeto;
- **IA generativa:** apoio no planejamento, revisão de requisitos, estruturação do conteúdo e validação documental.

Não foram utilizados React, Vue, Angular, Tailwind CSS, bibliotecas de interface ou funcionalidades simuladas no projeto entregue.

### 1.9 Versão publicada

O portfólio está disponível em:  
<https://portfolio-sarah-alencar.sarahandradealencar.chatgpt.site>

### 1.10 Resumo executivo da entrega

Esta entrega demonstra mais do que a criação visual de uma página. O trabalho parte de um levantamento de informações, transforma necessidades em histórias de usuário, define critérios de aceitação, prioriza o escopo, organiza um backlog e conecta cada requisito a uma implementação funcional. O resultado é um MVP publicado, responsivo, acessível e coerente com a trajetória apresentada.

| Dimensão | Evidência apresentada | Valor demonstrado |
|---|---|---|
| **Desempenho acadêmico** | Requisitos, histórias, critérios, MoSCoW, MVP, backlog e rastreabilidade documentados | Organização, análise e capacidade de transformar teoria em entrega |
| **Competência técnica** | HTML semântico, CSS responsivo e interações em JavaScript puro | Fundamentos web, lógica e atenção à experiência do usuário |
| **Maturidade profissional** | Experiências em atendimento, suporte técnico, caixa, gestão e desenvolvimento full stack | Versatilidade, responsabilidade e visão de processos |
| **Comunicação** | Inglês C2, espanhol C1, português nativo e vivência de seis meses nos Estados Unidos | Adaptação cultural e comunicação em contextos diversos |
| **Impacto humano** | Voluntariado com pessoas idosas, crianças com deficiência e departamentos da igreja | Empatia, escuta, colaboração e compromisso social |
| **Iniciativa** | Empreendedorismo desde cedo e portfólio planejado, implementado e publicado | Autonomia, persistência e capacidade de execução |

### 1.11 Desempenho, acessibilidade e qualidade

As melhorias de desempenho foram aplicadas sem alterar a proposta visual nem criar resultados artificiais. A página utiliza uma versão WebP da fotografia principal, mantém JPEG como alternativa, carrega o JavaScript de forma adiada, prioriza apenas a imagem visível no primeiro quadro e posterga a renderização das seções fora da tela. O redirecionamento inicial passou a ocorrer no servidor, evitando o carregamento de uma tela intermediária.

Também foram preservados HTML semântico, navegação por teclado, foco visível, rótulos acessíveis, preferência por movimento reduzido, textos alternativos e estados anunciados nas interações. Essas decisões favorecem velocidade percebida, inclusão e leitura profissional do projeto.

---

## 2. Prompts utilizados

Esta seção atende ao item obrigatório “Prompts utilizados” do enunciado. Para cada prompt relevante, são registrados objetivo, texto enviado, resultado obtido, análise crítica, decisão tomada e ajustes realizados. Não foram incluídas todas as conversas: os textos abaixo foram selecionados e consolidados a partir das orientações que realmente influenciaram o projeto.

### P01 — Levantamento de informações necessárias

**Objetivo do prompt:** identificar os dados pessoais, acadêmicos e profissionais necessários para construir um portfólio coerente com o enunciado.

**Texto enviado à IA:**

> Analise a atividade e me faça as perguntas que ela exige para conseguir gerar um portfólio pessoal completo.

**Resultado obtido:** foi produzido um questionário dividido em informações acadêmicas, apresentação, competências, experiências, projetos, hobbies, viagens, contatos, fotografia, estética e interações.

**Análise crítica da resposta:** o questionário cobriu os campos obrigatórios, mas inicialmente ficou extenso e algumas respostas permaneceram em branco. Foi necessário retomar somente os itens realmente essenciais e explicar o significado de prontuário/RA.

**Decisão tomada:** manter os dados respondidos, não inventar informações pessoais e sinalizar o prontuário como pendência antes da entrega.

**Ajuste realizado:** as perguntas repetidas foram eliminadas. Inicialmente, os projetos foram apresentados como “em desenvolvimento”, pois a autora informou não possuir projetos finalizados. Após a implementação, este próprio portfólio passou a ser registrado como a primeira entrega funcional concluída, sem alterar o status das demais frentes.

### P02 — Direção visual

**Objetivo do prompt:** definir uma identidade feminina e autoral sem comprometer a apresentação profissional.

**Texto enviado à IA:**

> Faça a atividade bem bonita, feminina e estilo journal. Use creme, rosa queimado, vinho e dourado. Use a imagem de portfólio como inspiração, mas não perca o profissionalismo e a elegância nem deixe com aparência muito juvenil.

**Resultado obtido:** foi proposta uma linguagem de scrapbook editorial com papéis, fita adesiva, polaroide, tipografia serifada, detalhes manuscritos e paleta sóbria.

**Análise crítica da resposta:** elementos de scrapbook em excesso poderiam prejudicar a leitura e criar aparência infantil. A referência também utilizava tipografia muito grande e composições assimétricas, que exigiam adaptação para um site responsivo.

**Decisão tomada:** usar os elementos de journal como detalhes de composição, preservando blocos de leitura objetivos, contraste, espaçamento e hierarquia profissional.

**Ajuste realizado:** o rosa vibrante da inspiração foi substituído por rosa queimado; textos manuscritos foram reduzidos; vinho e creme passaram a conduzir o contraste principal.

### P03 — Organização das experiências

**Objetivo do prompt:** transformar uma trajetória diversificada em conteúdo profissional e fácil de compreender.

**Texto enviado à IA:**

> Organize minhas experiências com voluntariado, capelania, teologia, assistência técnica, pizzaria nos Estados Unidos, salão de festas e empreendedorismo para que o portfólio fique profissional.

**Resultado obtido:** as experiências foram agrupadas em tecnologia e gestão, experiência internacional, eventos, empreendedorismo e voluntariado.

**Análise crítica da resposta:** uma lista extensa de funções poderia parecer desorganizada ou exagerada se não houvesse contexto. Também não foram informadas datas completas de todas as atividades.

**Decisão tomada:** destacar competências desenvolvidas em cada área sem inventar períodos, empresas ou resultados quantitativos.

**Ajuste realizado:** as descrições foram redigidas de forma objetiva, priorizando responsabilidades e aprendizados verificáveis.

### P04 — Funcionalidades em JavaScript

**Objetivo do prompt:** garantir interatividade real e aderência às restrições técnicas.

**Texto enviado à IA:**

> Implemente menu para celular, animações ao rolar, filtro de projetos, botão para copiar o e-mail, tema claro e escuro, galeria de viagens e formulário que abra o aplicativo de e-mail.

**Resultado obtido:** todas as interações foram implementadas com JavaScript puro.

**Análise crítica da resposta:** um formulário sem servidor não poderia prometer envio direto. Da mesma forma, botões de projetos sem links reais violariam o requisito de não simular funcionalidades.

**Decisão tomada:** fazer o formulário abrir o cliente de e-mail com assunto e mensagem preenchidos; não exibir botões de repositório ou demonstração enquanto não existirem links reais.

**Ajuste realizado:** foram adicionadas validação nativa, mensagem explicativa no formulário, fallback para cópia do e-mail e estados acessíveis para menu e galeria.

### P05 — Desempenho e posicionamento profissional

**Objetivo do prompt:** melhorar o desempenho técnico e reorganizar a apresentação para evidenciar a qualidade acadêmica e profissional da autora.

**Texto enviado à IA:**

> Melhore a performance tanto do site quanto do PDF para que a apresentação me favoreça, mostrando que sou uma ótima aluna e profissional. Também libere o site para que outras pessoas com outras contas consigam visualizar.

**Resultado obtido:** o conteúdo passou a apresentar um resumo de evidências, o portfólio foi reconhecido como primeira entrega funcional concluída e foram aplicadas otimizações de carregamento e renderização. O acesso do site foi alterado para público.

**Análise crítica da resposta:** favorecer a apresentação não poderia significar inventar notas, resultados, períodos, empresas ou competências. A melhoria deveria se apoiar somente em evidências reais fornecidas pela autora e em características verificáveis da própria entrega.

**Decisão tomada:** destacar competências por meio de fatos, como vivência internacional, idiomas, múltiplas funções profissionais, voluntariado, empreendedorismo e rastreabilidade do projeto.

**Ajuste realizado:** foram incluídos destaques objetivos no site, resumo executivo no documento e medidas de desempenho que não dependem de bibliotecas externas.

---

## 3. Histórias de usuário

| ID | História de usuário |
|---|---|
| **US01** | Como visitante, quero visualizar a identificação e a apresentação de Sarah para compreender rapidamente quem ela é e qual área estuda. |
| **US02** | Como visitante, quero conhecer sua formação, tecnologias, competências e idiomas para avaliar seu repertório. |
| **US03** | Como visitante, quero consultar suas experiências profissionais e voluntárias para entender sua trajetória e responsabilidades. |
| **US04** | Como visitante, quero visualizar a entrega concluída e as frentes em desenvolvimento para acompanhar sua evolução técnica. |
| **US05** | Como visitante, quero filtrar os projetos por categoria para localizar rapidamente o tipo de trabalho que me interessa. |
| **US06** | Como visitante, quero conhecer hobbies e viagens para compreender aspectos pessoais que complementam o perfil profissional. |
| **US07** | Como visitante, quero acessar meios reais de contato para iniciar uma conversa profissional. |
| **US08** | Como visitante em dispositivo móvel, quero usar um menu adaptado para navegar sem dificuldade. |
| **US09** | Como visitante, quero alternar entre tema claro e escuro para adequar a visualização à minha preferência. |
| **US10** | Como visitante, quero abrir detalhes das viagens e copiar o e-mail para interagir com o conteúdo sem perder o contexto da página. |
| **US11** | Como avaliador, quero identificar rapidamente evidências acadêmicas e profissionais para compreender os diferenciais de Sarah. |
| **US12** | Como visitante, quero que o portfólio carregue com eficiência para acessar o conteúdo sem esperas desnecessárias. |

---

## 4. Critérios de aceitação

### US01 — Identificação e apresentação

- A primeira seção deve exibir o nome “Sarah Alencar”.
- A apresentação deve informar que a autora estuda Análise e Desenvolvimento de Sistemas.
- A fotografia fornecida deve possuir texto alternativo.
- Devem existir atalhos funcionais para projetos e contato.

### US02 — Formação, competências e idiomas

- A seção deve exibir IFSP, curso, semestre e previsão de conclusão.
- Devem ser listadas pelo menos cinco tecnologias ou ferramentas.
- Devem ser listadas pelo menos quatro competências pessoais.
- Os quatro idiomas informados devem possuir seus respectivos níveis.

### US03 — Experiências

- Devem existir blocos distintos para assistência técnica, experiência internacional, eventos e empreendedorismo.
- O voluntariado deve mencionar atuação com pessoas idosas, crianças com deficiência e departamentos da igreja.
- Nenhuma empresa, data ou resultado não fornecido pode ser inventado.
- O conteúdo deve continuar legível em telas menores.

### US04 — Entrega concluída e frentes em desenvolvimento

- A seção deve identificar este portfólio como primeira entrega funcional concluída.
- Cada item deve possuir nome, descrição, etapa e tecnologias.
- Não devem existir botões de repositório ou demonstração sem link real.
- Devem ser apresentados no mínimo três trabalhos, entre entrega concluída e frentes em desenvolvimento.

### US05 — Filtro de projetos

- Deve existir opção para exibir todos os projetos.
- Devem existir filtros para Web, Código e Design.
- Ao selecionar um filtro, somente cartões pertencentes à categoria correspondente devem permanecer visíveis.
- O filtro selecionado deve possuir estado visual identificável.

### US06 — Hobbies e viagens

- A seção deve apresentar academia, corrida e convivência com pessoas queridas.
- A experiência de seis meses nos Estados Unidos deve ser apresentada.
- O cruzeiro por Santos, Búzios e Maceió deve ser apresentado.
- Os detalhes de viagens devem ser acessíveis por botão e janela de diálogo.

### US07 — Contato

- O e-mail exibido deve utilizar protocolo `mailto:`.
- O link do Instagram deve abrir o perfil informado.
- O formulário deve exigir nome, e-mail válido e mensagem.
- O envio deve abrir o aplicativo de e-mail com assunto e corpo preenchidos.

### US08 — Navegação móvel

- O menu móvel deve aparecer em telas com largura de até 960 px.
- O botão deve informar seu estado com `aria-expanded`.
- O menu deve fechar após a seleção de um link ou ao pressionar Escape.
- Nenhuma seção deve provocar rolagem horizontal indevida.

### US09 — Tema claro e escuro

- O botão deve alternar as variáveis de cores da página.
- A preferência deve ser registrada apenas no armazenamento local do navegador.
- Ao retornar, o tema escolhido deve ser restaurado.
- O botão deve possuir rótulo acessível correspondente à ação disponível.

### US10 — Interações auxiliares

- O botão “Copiar e-mail” deve copiar o endereço informado.
- Uma mensagem de sucesso deve ser anunciada após a cópia.
- A galeria deve abrir uma janela com título e descrição da viagem.
- A janela deve possuir botão de fechar e também fechar ao clicar no fundo.

### US11 — Evidências acadêmicas e profissionais

- A página deve apresentar destaques verificáveis da trajetória.
- O conteúdo não pode inventar notas, empresas, datas ou resultados quantitativos.
- O portfólio concluído deve ser identificado como uma entrega funcional e publicada.
- A documentação deve relacionar evidências a competências demonstradas.

### US12 — Desempenho e carregamento

- A fotografia principal deve possuir formato otimizado e alternativa compatível.
- O script principal deve ser carregado de forma adiada.
- As seções fora da primeira tela devem permitir renderização progressiva.
- A abertura do endereço principal não deve carregar uma tela intermediária antes do portfólio.

---

## 5. Priorização MoSCoW

| Classificação | Histórias | Justificativa |
|---|---|---|
| **Must have** | US01, US02, US03, US04, US07, US08, US11, US12 | Identificação, formação, experiências, projetos, contato, responsividade, evidências e desempenho são essenciais para a qualidade profissional do portfólio. |
| **Should have** | US05, US06, US09, US10 | Filtros, conteúdo pessoal, tema e interações aumentam a qualidade da experiência, mas o conteúdo principal ainda poderia ser consultado sem eles. |
| **Could have** | Download de currículo, versão em inglês e imagens próprias para cada viagem. | São melhorias coerentes, mas dependem de materiais e dados que ainda não foram fornecidos. |
| **Won't have now** | Blog, autenticação, banco de dados, painel administrativo e envio de formulário por servidor. | Esses recursos ampliariam o escopo e exigiriam tecnologias ou infraestrutura além do MVP e das restrições desta entrega. |

---

## 6. Descrição do MVP

### 6.1 Necessidades atendidas

O MVP reúne, em uma única página responsiva, as informações necessárias para apresentar Sarah ao público geral: identidade, formação, competências, idiomas, experiências, entrega web concluída, frentes de estudo, interesses, viagens e contatos reais.

### 6.2 Seções disponíveis

- apresentação inicial;
- sobre mim e formação;
- tecnologias, competências e idiomas;
- experiências e voluntariado;
- entrega web concluída e frentes em desenvolvimento;
- hobbies e viagens;
- contato.

### 6.3 Interações implementadas

- menu móvel;
- rolagem por âncoras;
- animações suaves;
- filtro de projetos;
- tema claro e escuro;
- cópia do e-mail;
- galeria de viagens;
- formulário integrado ao cliente de e-mail.

### 6.4 Histórias incluídas

O MVP inclui as histórias **US01, US02, US03, US04, US07, US08, US11 e US12**, classificadas como Must have. As histórias US05, US06, US09 e US10 também foram implementadas para elevar a qualidade da entrega.

### 6.5 Fora da primeira versão

- projetos com repositório ou demonstração publicados;
- currículo para download;
- tradução integral para inglês;
- blog e painel de atualização;
- envio de mensagens por servidor;
- banco de dados.

### 6.6 Condições de conclusão

O MVP é considerado concluído quando:

1. todas as seções obrigatórias estiverem presentes;
2. as histórias Must have atenderem aos critérios de aceitação;
3. os links de e-mail e Instagram funcionarem;
4. o menu e o layout se adaptarem a computadores e celulares;
5. as interações em JavaScript funcionarem sem bibliotecas externas;
6. a documentação corresponder ao conteúdo realmente implementado;
7. não existirem links ou botões simulados.

---

## 7. Backlog acionável

| ID | Item do backlog | História | Prioridade | Critérios de aceitação resumidos | Status |
|---|---|---|---|---|---|
| **BL01** | Estruturar cabeçalho e navegação semântica | US08 | Must have | Links internos e menu adaptado para celular | Concluído |
| **BL02** | Criar apresentação inicial com fotografia | US01 | Must have | Nome, área, foto, descrição e dois atalhos | Concluído |
| **BL03** | Redigir seção “Sobre mim” | US01 | Must have | Texto profissional coerente com dados fornecidos | Concluído |
| **BL04** | Inserir formação acadêmica e complementar | US02 | Must have | IFSP, ADS, semestre, conclusão, Capelania e Teologia | Concluído |
| **BL05** | Listar tecnologias, competências e idiomas | US02 | Must have | Informações completas e níveis visíveis | Concluído |
| **BL06** | Organizar experiências em linha narrativa | US03 | Must have | Quatro áreas profissionais sem dados inventados | Concluído |
| **BL07** | Criar bloco de voluntariado | US03 | Must have | Público atendido e departamentos apresentados | Concluído |
| **BL08** | Criar cartões de entrega e frentes de estudo | US04 | Must have | Três itens com etapa e tecnologias | Concluído |
| **BL09** | Implementar filtro de projetos | US05 | Should have | Todos, Web, Código e Design funcionais | Concluído |
| **BL10** | Criar seção de hobbies | US06 | Should have | Academia, corrida e convivência apresentados | Concluído |
| **BL11** | Implementar galeria de viagens | US06, US10 | Should have | Dois cartões abrem detalhes em diálogo | Concluído |
| **BL12** | Implementar tema claro e escuro | US09 | Should have | Alternância e preferência local funcionais | Concluído |
| **BL13** | Implementar cópia de e-mail | US10 | Should have | Cópia e mensagem de sucesso | Concluído |
| **BL14** | Implementar formulário de contato | US07 | Must have | Validação e abertura do cliente de e-mail | Concluído |
| **BL15** | Revisar acessibilidade e responsividade | US01–US10 | Must have | Semântica, teclado, contraste e telas móveis | Concluído |
| **BL16** | Criar documentação e README | US01–US10 | Must have | Rastreabilidade e instruções completas | Concluído |
| **BL17** | Adicionar currículo para download | — | Could have | Arquivo real e botão funcional | Não iniciado |
| **BL18** | Criar versão integral em inglês | — | Could have | Alternância de idioma e conteúdo traduzido | Não iniciado |
| **BL19** | Evidenciar diferenciais acadêmicos e profissionais | US11 | Must have | Destaques verificáveis e resumo executivo | Concluído |
| **BL20** | Otimizar carregamento e renderização | US12 | Must have | Imagem otimizada, script adiado e abertura direta | Concluído |

---

## 8. Matriz de rastreabilidade

| História | Seção/funcionalidade implementada | Itens do backlog |
|---|---|---|
| US01 | Hero e Sobre mim | BL02, BL03 |
| US02 | Formação, Repertório e Idiomas | BL04, BL05 |
| US03 | Experiências e Voluntariado | BL06, BL07 |
| US04 | Entrega concluída e frentes em desenvolvimento | BL08 |
| US05 | Filtros de projetos | BL09 |
| US06 | Hobbies e Viagens | BL10, BL11 |
| US07 | E-mail, Instagram e formulário | BL14 |
| US08 | Cabeçalho e menu móvel | BL01, BL15 |
| US09 | Tema claro e escuro | BL12 |
| US10 | Cópia de e-mail e diálogo de viagens | BL11, BL13 |
| US11 | Faixa de destaques, diferenciais e resumo executivo | BL19 |
| US12 | Imagem WebP, carregamento adiado e renderização progressiva | BL20 |

---

## 9. Organização dos arquivos

```text
portfolio/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── script.js
├── assets/
│   ├── sarah-profile.jpeg
│   └── sarah-profile.webp
├── docs/
│   ├── documentacao.md
│   └── documentacao.pdf
└── README.md
```

---

## 10. Verificação final

- [x] Conteúdo de identificação e apresentação implementado.
- [x] Formação acadêmica apresentada.
- [x] Competências, tecnologias e idiomas apresentados.
- [x] Experiências profissionais e voluntárias apresentadas.
- [x] Portfólio apresentado como entrega funcional concluída e demais frentes como “em desenvolvimento”.
- [x] Hobbies e viagens incluídos.
- [x] Contatos reais e funcionais.
- [x] Menu para celular implementado.
- [x] Interações em JavaScript implementadas.
- [x] Layout responsivo.
- [x] HTML semântico.
- [x] Documentação alinhada à implementação.
- [x] Prontuário acadêmico atualizado para `GU3078698`.
- [x] Evidências acadêmicas e profissionais apresentadas sem informações inventadas.
- [x] Carregamento e renderização otimizados.
- [x] Site liberado para visualização pública.
