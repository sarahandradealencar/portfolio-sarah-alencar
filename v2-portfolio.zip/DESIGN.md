# Sistema visual — Entre Linhas

## Direção

Portfólio em formato de diário editorial. Papel, vinho, rosa e dourado compõem uma identidade pessoal já estabelecida na v1. A v2 preserva essa linguagem e melhora clareza, legibilidade, responsividade e estados de interação.

## Tokens e componentes

As cores, famílias tipográficas, bordas e sombras são definidas em `public/portfolio/css/style.css`. Georgia é a voz editorial; sans-serif serve a leitura funcional. Cabeçalho, botões, cartões, filtros, formulário e diálogo reutilizam os mesmos tokens. Ambos os temas devem manter contraste suficiente.

## Regras de uso

- Texto de leitura e controles devem ser legíveis sem zoom e suportar ampliação.
- Links e botões precisam de rótulos claros, área de toque adequada e foco visível.
- Movimento é auxiliar e nunca oculta conteúdo quando JavaScript ou preferências de movimento interferem.
- Elementos decorativos não devem competir com o conteúdo profissional.
- Novas páginas mantêm cabeçalho, cores, tipografia e navegação do portfólio.

## Vínculo com o produto

Ver `PRODUCT.md` para público, fatos e objetivos. A versão anterior está marcada em Git como `v1`.
